import random
import urllib3
import requests, re, time
from django.http import HttpResponse
from lxml import etree
from multiprocessing.dummy import Pool
# from multiprocessing import Pool
from fake_useragent import UserAgent
from . import models

# Create your views here.
def getPage(url):
    # time.sleep(random.random() * random.randint(1, 5))
    ua = UserAgent()
    headers = {
        'User-Agent': ua.random,
        'Referer': 'https://www.xbiquwx.la/',
        'Connection': 'close'
    }
    urllib3.disable_warnings()
    response = requests.get(url=url, headers=headers)
    response.encoding = response.apparent_encoding
    page = response.text
    return page
def getNovels(i):
    url = f'https://www.xbiquwx.la/list/1_{i}.html'
    page = getPage(url)
    tree = etree.HTML(page)
    novelsHref = tree.xpath('//div[@class="l"]/ul/li/span[@class="s2"]/a/@href')
    print(novelsHref)
    hrefs.extend(novelsHref)
    return novelsHref

hrefs=[]
def getNovelsHref(request):
    # hrefs = []
    pool = Pool(50)
    hre=pool.map(getNovels,range(570,560,-1))
    pool.map(getNovelInfo,hrefs)
    pool.close()
    pool.join()

    return HttpResponse('加载完成啦啦啦啦啦啦啦啦啦啦啦')


def getNovelInfo(url):
    print('*'*200)

    time.sleep(random.random() * random.randint(1, 5))
    page = getPage(url)
    tree = etree.HTML(page)
    name = tree.xpath('//div[@id="info"]/h1/text()')[0] #小说名字
    writer = tree.xpath('//div[@id="info"]/p/text()')[0][7::]   #作者名字
    preface = tree.xpath('//div[@id="intro"]/p')[0]
    preface = getNovelPre(preface)  #小说简介
    judge = models.Fantasy.objects.filter(name=name, writer=writer)
    if judge:
        mod = judge[0].id
    else:
        mod = models.Fantasy.objects.create(name=name, writer=writer, preface=preface)
    # mod = models.Fantasy.objects.create(name=name, writer=writer, preface=preface)
    urls, hrefs = getNovelChapter(url,page)
    print(name)
    print(writer)
    # mod=1
    dat={
        'mod':mod,
        'urls':urls
    }
    for url in urls:
        pool = Pool(150)
        pool.apply_async(getNovelContent,(url,mod))
        pool.close()
        pool.join()
    # list(map(getNovelContent, (urls,mod)))
    print('======================================')

def getNovelContent(url,mod):
    time.sleep(random.random() * random.randint(1, 5))
    page = getPage(url)
    tree = etree.HTML(page)
    title = tree.xpath('//div[@class="bookname"]/h1/text()')[0]
    content = tree.xpath('//div[@id="content"]')[0]
    content = getNovelPre(content)
    judge = models.FantasyNovelChapter.objects.filter(chapter=title, name=mod).update(content=content)
    if not judge:
        models.FantasyNovelChapter.objects.create(chapter=title, content=content, name=mod)
    # models.FantasyNovelChapter.objects.create(chapter=title,content=content,name=mod)
    print(title)
    print(content)
    # return title, content


def getNovelChapter(hre,page):
    tree=etree.HTML(page)
    href=tree.xpath('//div[@id="list"]/dl/dd/a/@href')
    getUrls = lambda url: hre + url
    return list(map(getUrls, href)), href


def getNovelPre(con):
    con = con.xpath('.//text()')
    text = ''
    for pre in con:
        text += pre
    return text

