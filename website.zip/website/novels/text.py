import random

import requests, re,time
from django.http import HttpResponse
from lxml import etree
from multiprocessing.dummy import Pool
from fake_useragent import UserAgent

# Create your views here.
def getPage(url):
    time.sleep(random.random()*random.randint(1,5))
    ua=UserAgent()
    headers = {
        'User-Agent': ua.random,
        'Referer': 'https://www.qbiqu.com/',
        'Connection': 'close'
    }

    response = requests.get(url=url, headers=headers)
    response.encoding = response.apparent_encoding
    page = response.text
    return page


def getNovelsHref(request):
    url='https://www.qbiqu.com/xuanhuanxiaoshuo/1_1.html'
    page=getPage(url)
    tree=etree.HTML(page)
    novelsHref=tree.xpath('//div[@class="l"]/ul/li/span[@class="s2"]/a/@href')
    print(novelsHref)
    # novelsHref[0]='https://www.qbiqu.com/96_96391/'
    getNovelInfo(novelsHref[0])
    # novel_pool=Pool(20)
    # novel_pool.map(getNovelInfo,novelsHref)
    # novel_pool.close()
    # novel_pool.join()
    # url = 'https://www.qbiqu.com/96_96391/'
    # getNovelInfo(url)
    return HttpResponse('加载完成啦啦啦啦啦啦啦啦啦啦啦')

def getNovelInfo(url):
    time.sleep(random.random()*random.randint(1,5))
    page = getPage(url)
    tree = etree.HTML(page)
    # tree=getPage(url)
    name = tree.xpath('//div[@id="info"]/h1/text()')[0]
    writer = tree.xpath('//div[@id="info"]/p/text()')[0][7::]
    preface = tree.xpath('//div[@id="intro"]/p')[0]
    preface = getNovelPre(preface)

    urls, hrefs = getNovelChapter(page)
    pool=Pool(30)
    pool.map(getNovelContent,urls)
    pool.close()
    pool.join()
    list(map(getNovelContent,urls))

def getNovelContent(url):
    time.sleep(random.random()*random.randint(1,5))
    page = getPage(url)
    tree = etree.HTML(page)
    title = tree.xpath('//div[@class="bookname"]/h1/text()')[0]
    content = tree.xpath('//div[@id="content"]')[0]
    content = getNovelPre(content)
    print(title)
    print(content)
    return title, content


def getNovelChapter(page):
    pattern = re.compile('<div id="list">.*<dt>.*</dt>.*?<dd>(.*)</dd>', re.S)
    # pattern=re.compile('<dd>(.*?)</dd>',re.S)
    data = pattern.findall(page)[0]
    pattern = re.compile('<a href="(.*?)">.*?</a>', re.S)
    href = pattern.findall(data)
    getUrls = lambda url: 'https://www.qbiqu.com' + url
    return list(map(getUrls, href)), href


def getNovelPre(con):
    con = con.xpath('.//text()')
    text = ''
    for pre in con:
        text += pre
    return text


# if __name__ == '__main__':
#     getNovelsHref()