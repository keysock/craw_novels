from django.db import models

# Create your models here.
class Fantasy(models.Model):
    name=models.CharField(max_length=50)
    writer=models.CharField(max_length=50)
    preface=models.TextField()

class FantasyNovelChapter(models.Model):
    chapter=models.CharField(max_length=200)
    content=models.TextField()
    name=models.ForeignKey(Fantasy,on_delete=models.CASCADE)