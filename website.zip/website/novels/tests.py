import random
import urllib3
import requests, re, time
from django.http import HttpResponse
from lxml import etree
from multiprocessing.dummy import Pool
from fake_useragent import UserAgent


# Create your views here.
def getPage(url):
    time.sleep(random.random() * random.randint(1, 5))
    ua = UserAgent()
    headers = {
        'User-Agent': ua.random,
        'Referer': 'https://www.xbiquwx.la/',
        'Connection': 'close'
    }
    urllib3.disable_warnings()
    response = requests.get(url=url, headers=headers)
    response.encoding = response.apparent_encoding
    page = response.text
    return page


def getNovelsHref():
    url = 'https://www.xbiquwx.la/list/1_1.html'
    page = getPage(url)
    tree = etree.HTML(page)
    novelsHref = tree.xpath('//div[@class="l"]/ul/li/span[@class="s2"]/a/@href')
    print(novelsHref)
    # novelsHref[0]='https://www.qbiqu.com/96_96391/'
    # getNovelInfo(novelsHref[0])
    novel_pool=Pool(20)
    novel_pool.map(getNovelInfo,novelsHref)
    novel_pool.close()
    novel_pool.join()
    # url = 'https://www.qbiqu.com/96_96391/'
    # getNovelInfo(url)
    # return HttpResponse('加载完成啦啦啦啦啦啦啦啦啦啦啦')


def getNovelInfo(url):
    time.sleep(random.random() * random.randint(1, 5))
    page = getPage(url)
    tree = etree.HTML(page)
    # tree=getPage(url)
    name = tree.xpath('//div[@id="info"]/h1/text()')[0]
    writer = tree.xpath('//div[@id="info"]/p/text()')[0][7::]
    preface = tree.xpath('//div[@id="intro"]/p')[0]
    preface = getNovelPre(preface)

    urls, hrefs = getNovelChapter(url,page)
    pool = Pool(30)
    pool.map(getNovelContent, urls)
    pool.close()
    pool.join()
    # list(map(getNovelContent, urls))


def getNovelContent(url):
    time.sleep(random.random() * random.randint(1, 5))
    page = getPage(url)
    tree = etree.HTML(page)
    title = tree.xpath('//div[@class="bookname"]/h1/text()')[0]
    content = tree.xpath('//div[@id="content"]')[0]
    content = getNovelPre(content)
    print(title)
    print(content)
    return title, content


def getNovelChapter(hre,page):
    tree=etree.HTML(page)
    href=tree.xpath('//div[@id="list"]/dl/dd/a/@href')
    getUrls = lambda url: hre + url
    return list(map(getUrls, href)), href


def getNovelPre(con):
    con = con.xpath('.//text()')
    text = ''
    for pre in con:
        text += pre
    return text


if __name__ == '__main__':
    getNovelsHref()
from django.test import TestCase

# Create your tests here.
