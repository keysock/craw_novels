import pyinputplus as pyip
response=pyip.inputNum(allowRegexes=[r'(I|V|X|L|C|D|M)+'])
print(response)